from django.http import HttpResponse
from django.shortcuts import render


# Create your views here.

def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')
        return HttpResponse("Спасибо за ваше сообщение!")
    return render(request, 'contact/contact.html')
